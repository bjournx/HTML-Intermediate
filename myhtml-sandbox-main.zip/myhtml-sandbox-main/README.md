Partners:

Reyes, John Carl A.
Cloyd Talirongan
